

$(function () {

  $( ".uDate" ).datepicker();
  $( ".uDate" ).datepicker( "option", "dateFormat", "dd.mm.yy");





                    



});